import React from 'react';
import { Typography } from '@mui/material';

function stockpage() {
  return (
    <>
      <Typography variant="h4" gutterBottom>
        Stock Page
      </Typography>
      {/* We'll add the PriceChart component here later */}
    </>
  );
}

export default stockpage;