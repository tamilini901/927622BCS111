import React from 'react';
import { Typography } from '@mui/material';

function heatmappage() {
  return (
    <>
      <Typography variant="h4" gutterBottom>
        Heatmap Page
      </Typography>
      {/* We'll add the HeatmapChart component here later */}
    </>
  );
}

export default heatmappage;