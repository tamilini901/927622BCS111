// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { AppBar, Toolbar, Typography, Button, Container } from '@mui/material';

import stockpage from './modules/stockpage';
import heatmappage from './modules/heatmappage';

function App() {
  return (
    <Router>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            STOCK DETAILS
          </Typography>
          <Button color="inherit" component={Link} to="/">Stocks</Button>
          <Button color="inherit" component={Link} to="/heatmap">Heatmap</Button>
        </Toolbar>
      </AppBar>

      <Container sx={{ mt: 4 }}>
        <Routes>
          <Route path="/" element={<stockpage />} />
          <Route path="/heatmap" element={<heatmappage />} />
        </Routes>
      </Container>
    </Router>
  );
}

export default App;
